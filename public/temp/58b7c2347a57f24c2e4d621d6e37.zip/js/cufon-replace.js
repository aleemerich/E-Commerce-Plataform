Cufon.replace('#header .row-2 ul li', { fontFamily: 'NewsGoth Dm BT', textShadow:'#397ece 1px 1px' });
Cufon.replace('h2', { fontFamily: 'NewsGoth BT', color: '-linear-gradient(#fff, #fff, #fff, #fff, #fff, #fff, #cccccc, #cccccc, #cccccc, #cccccc, #cccccc)' });
Cufon.replace('h2 b', { fontFamily: 'NewsGoth BT Bold', color: '-linear-gradient(#3b98dd, #3b98dd, #3b98dd, #3b98dd, #3b98dd, #3b98dd, #1f7dd2, #1f7dd2, #1f7dd2, #1f7dd2, #1f7dd2)' });
Cufon.replace('#search-form label', { fontFamily: 'NewsGoth Dm BT' });
Cufon.replace('.link1', { fontFamily: 'NewsGoth Dm BT', textShadow:'#165ebd 1px 1px' });
Cufon.replace('h3, h4', { fontFamily: 'Myriad Pro Regular' });
Cufon.replace('h3 b, h4 b', { fontFamily: 'Myriad Pro Semibold' });
Cufon.replace('.box2 h4, .box3 h4', { fontFamily: 'Myriad Pro Semibold', textShadow:'#2074cb 1px 1px' });